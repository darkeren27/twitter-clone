require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const { MongoMemoryServer } = require('mongodb-memory-server');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// MongoDB connection
let mongoServer;
async function connectDB() {
  const mongoUri = process.env.MONGO_URI;
  if (mongoUri) {
    await mongoose.connect(mongoUri);
    console.log('Connected to MongoDB');
  } else {
    mongoServer = await MongoMemoryServer.create();
    const uri = mongoServer.getUri();
    await mongoose.connect(uri);
    console.log('Connected to in-memory MongoDB');
  }
}

// Tweet model
const tweetSchema = new mongoose.Schema(
  {
    content: { type: String, required: true, maxlength: 140 },
    createdAt: { type: Date, default: Date.now },
  },
  { versionKey: false }
);

const Tweet = mongoose.model('Tweet', tweetSchema);

// REST API routes
app.get('/api/tweets', async (req, res) => {
  try {
    const tweets = await Tweet.find().sort({ createdAt: -1 }).limit(100);
    res.json(tweets);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch tweets' });
  }
});

app.post('/api/tweets', async (req, res) => {
  try {
    const { content } = req.body;
    if (!content || content.trim().length === 0) {
      return res.status(400).json({ error: 'Tweet content is required' });
    }
    if (content.length > 140) {
      return res.status(400).json({ error: 'Tweet exceeds 140 characters' });
    }
    const tweet = await Tweet.create({ content: content.trim() });
    broadcastTweet(tweet);
    res.status(201).json(tweet);
  } catch (err) {
    res.status(500).json({ error: 'Failed to post tweet' });
  }
});

// Server-Sent Events for real-time feed
const clients = new Set();

app.get('/api/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  const client = { res };
  clients.add(client);

  // Send a ping comment periodically to keep the connection alive
  const ping = setInterval(() => {
    res.write(': ping\n\n');
  }, 20000);

  req.on('close', () => {
    clearInterval(ping);
    clients.delete(client);
  });
});

// Helper to broadcast new tweets to SSE clients
function broadcastTweet(tweet) {
  const data = `data: ${JSON.stringify(tweet)}\n\n`;
  for (const client of clients) {
    client.res.write(data);
  }
}


const PORT = process.env.PORT || 3000;

connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(`Server listening on http://localhost:${PORT}`);
  });
});